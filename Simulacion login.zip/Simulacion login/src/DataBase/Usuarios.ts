export const Usuarios = [
    {correo: "admin@gmail.com", password: "admin", rol: "admin"},
    {correo: "josue@gmail.com", password: "1234", rol: "user"},
    {correo: "user@gmail.com", password: "user", rol: "user"},
    {correo: "prueba@gmail.com", password: "prueba", rol: "user"},
    {correo: "uslog@gmail.com", password: "login", rol: "admin"}
]